package siva;
import java.util.Scanner;
public class Withreturntype {

	public void display() {
		System.out.println("Hi nice to meet you");
	
   }
	public static void main(String[] args) {
		Withreturntype obj=new Withreturntype();
		obj.display();
		
	}

}
