package siva;

public class Stringbuffer {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("hello");
		System.out.println(sb);
		sb.append(",world");
		System.out.println(sb);
		sb.insert(5, "java");
		System.out.println(sb);
		sb.delete(5, 10);
		System.out.println(sb);
		sb.reverse();
		System.out.println(sb);
		sb.replace(0, 3, "AA");
		System.out.println(sb);

	}

}

