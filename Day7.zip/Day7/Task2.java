package siva;

public class Task2 {
	int age;
	String name;
	

		public void display(int age,String name) {
			System.out.println(age+" "+name);
		
	   }
		public static void main(String[] args) {
			Withreturntype obj=new Withreturntype();
			obj.display(10,"ajmal");
			
		}

	}


