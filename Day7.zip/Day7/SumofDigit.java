package siva;
import java.util.Scanner;
public class SumofDigit {

	public int add(int a,int b) {
		int sum= a + b;
		return sum;
		

	}
	public static void main(String[] args) {
		SumofDigit obj=new SumofDigit();
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		int num1=scan.nextInt();
		obj.add(num,num1);
		
	}

}
