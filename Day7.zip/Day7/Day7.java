package siva;

public class Day7 {

	public static void main(String[] args) {
		String str=" Naveen Monish";
		String str1="naveen";
		String str2=new String("Naveen");
		String str3=new String("YellowMatics");
		System.out.println(str==str1);
		System.out.println(str.equals(str1));
		System.out.println(str.equalsIgnoreCase(str1));
		System.out.println(str.length());
		System.out.println(str);
		String word[]=str.split(" ");
		for(String var:word) {
			System.out.println(var);
		}
		System.out.println(str3.substring(5));
		System.out.println(str3.contains("kir"));
		System.out.println(str3.endsWith("cs"));
		System.out.println(str3.charAt(3));
		System.out.println(str3.concat(" Gether"));
		
		
		
  
	}

}
