package siva;

public class Withoutreturntype {

	public String display() 
	{
		String name="Sivabalan";
		return name;

	}
	public static void main(String[] agrs) {
		Withoutreturntype obj=new Withoutreturntype();
		String res=obj.display();
		System.out.println(res);
	}

}
