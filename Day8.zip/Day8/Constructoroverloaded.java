package Day8;

public class Constructoroverloaded {
	int age;
	String name;
	Constructoroverloaded(){
          System.out.println("hi");
	}
	Constructoroverloaded(int a, String str){
		System.out.println(a+" "+str);
	}
	Constructoroverloaded(float b){
		System.out.println(b);
	}

	public static void main(String[] args) {
		Constructoroverloaded obj = new Constructoroverloaded(5,"roshan");
		Constructoroverloaded obj1= new Constructoroverloaded((int) 5f,"roshan");
		
		

	}

}
