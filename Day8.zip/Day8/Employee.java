package Day8;
//static method
public class Employee {
	int rollno=55;
	String name="Akash";
	static String collegename="zion";
	void display(int a, String name) {
		System.out.println(a+" "+name+" "+collegename);
	}

	public static void show(int a) {
		Employee. collegename="mount zion";
		System.out.println(a+" "+collegename);

	}
	public static void main(String[] args) {
	   Employee.show(55);
	   Employee obj=new Employee();
	   obj.display(65, "Akash");
	   
		
	}

}
