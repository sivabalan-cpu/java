package Day8;
//multilevel inheritance
class Grandpa{
	void display() {
		System.out.println("villa");
		
	}
}
class Dad1 extends Grandpa{
	void property() {
		System.out.println("house,land,bike");
	}
}
class Son1 extends Dad1{
	void show() {
		System.out.println("car");
	}
}
public class Main4{

	public static void main(String[] args){
		Son1 obj=new Son1();
		obj.property();
		obj.display();
		

	}

}
