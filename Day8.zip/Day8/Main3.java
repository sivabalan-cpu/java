package Day8;
//single inheritance
class Dad{
	void property() {
		System.out.println("house,money,lands");
	}
}
class Son extends Dad{
	void show() {
		System.out.println("bike");
	}
}
public class Main3 {
	
	public static void main(String[] args) {
		Son obj=new Son();
		obj.property();
		obj.show();

	}

}
