package Day8;
//higher logical;
class Dad3{
	void property() {
		System.out.println("house,lands,villa");
	}
}
class Son3 extends Dad3
{
	void show(){
		System.out.println("bike");
	}
}
class Daughter3 extends Dad3
{
	void display() {
		System.out.println("jewel");
	}
	}
	public class Task1{
	
	public static void main(String[] args) {
		Daughter3 obj=new  Daughter3();
		obj.property();
		obj.display();
		
		
		
		
		

	}

}
