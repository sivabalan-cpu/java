package Day8;
//this keyword2
public class Main1 {
	String name;
	void display() {
		System.out.println("hello display");
	}
	void show() {
		this.display();
		System.out.println("hello show");
	}
	

	public static void main(String[] args) {
		Main1 obj=new Main1();
		obj.show();
		

	}

}
