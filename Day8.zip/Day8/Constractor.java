package Day8;
// constructor
public class Constractor {
	int age;
	String name;
	Constractor(){
		System.out.println("hi");
	}
	Constractor(int a,String str){
		age=a;
		name=str;
		
	}
	void display() {
		System.out.println(age+""+name);
	}

	public static void main(String[] args) {
		Constractor obj= new Constractor();
		Constractor obj1= new Constractor(20,"roshan");
		
		
		

	}
	
	
	
	
}
