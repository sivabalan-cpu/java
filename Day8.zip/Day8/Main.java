package Day8;
//this keyword
public class Main {
	int age;
	String name;
	Main(int age, String name){
	this.age=age;
		this.name=name;
	}
	void display() {
		System.out.println(age+" "+name);
	}
	

	public static void main(String[] args) {
		Main obj=new Main(5,"roshan");
		obj.display();

	}

}
