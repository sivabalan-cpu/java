package Day8;

public class Trip {
	String placename;
	String hotelname;
	String food;

	public static void main(String[] args) {
		

	}

}
