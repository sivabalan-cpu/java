package Day8;

public class Task2 {
	static {
		System.out.println("mount zion");
	}

	public static void main(String[] args) {
		
        System.out.println("nice to meet you!");
	}

}
