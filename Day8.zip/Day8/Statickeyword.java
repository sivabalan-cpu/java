package Day8;

public class Statickeyword {
	int rollno=55;
	String name="Akash";
	static String collegename ="zion";
	void display(int a,String name) {
		System.out.println(a+" "+name+" "+collegename);
	}

	public static void main(String[] args) {
		Statickeyword obj=new Statickeyword();
//		System.out.println(obj.rollno);
//		System.out.println(Statickeyword.collegename);
		Statickeyword.collegename="mount";
		obj.display(55, "Akash");
		obj.display(56, "Ajay");
		obj.display(57, "Ashwin");
		obj.display(58, "Arjun");
		obj.display(58, "Siva");
		
		
		
		
		

	}

}
