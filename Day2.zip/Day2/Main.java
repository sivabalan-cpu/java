package siva;
//assignment operater
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		int num1=9656;
		
	    
		System.out.println(num1%1000);//9656%1000=656
		
		
		

	}

}
