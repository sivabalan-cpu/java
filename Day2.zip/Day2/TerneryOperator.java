package siva;

public class TerneryOperator {

	public static void main(String[] args) {
		int a=8;
		int b=6;
		int max=(a>b)?a:b;//8>6 then print 8 or 6 
		System.out.println(max);//8

	}

}
