package siva;

public class RightShifter {

	public static void main(String[] args) {
		int a=5;
		int b=2;
		System.out.println(a>>  b);//5>> 2=1
	}

}
