package siva;
import java.util.Scanner;
public class ArithmaticOperator {

	public static void main(String[] args) {
		    Scanner obj = new Scanner(System.in);
				System.out.print("Enter the num:");
				int num= obj.nextInt();//10
				int mod=num%10;//10%10=0
				int div=num/10;//10/10=1
				System.out.println(mod + div);//0+1=1
				
				

			}

		}


