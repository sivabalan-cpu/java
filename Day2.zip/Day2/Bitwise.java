package siva;

public class Bitwise {
	 public static void main(String agrs[]){
		 int num1= 15;
		 int num2=20;
		 System.out.println(num1&num2);//15&20=4
		 System.out.println(num1|num2);//15/20=31
		 System.out.println(num1^num2);//15^20=27
		 
		 int num3=10;
		 int num4=25;
		 System.out.println(num3|num4);//10/25=27
		 int num5=30;
		 int num6=25;
		 System.out.println(num5^num6);//30/25=7
	 }
}
