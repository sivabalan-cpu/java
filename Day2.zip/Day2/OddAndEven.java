package siva;
import java.util.Scanner;
public class OddAndEven {
     public static void main(String[] args) {
    	 Scanner scan=new Scanner(System.in);
    	 int num=scan.nextInt();//4
    	 String num2=(num%2==0)?"even":"odd";//4%2==0 yes then print even or add
		System.out.println(num2);//even
	}

}
