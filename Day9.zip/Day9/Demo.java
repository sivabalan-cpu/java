package Day9;
public class Demo{
	    String name;
		int age;
		 void display() {
			 System.out.println( name+" "+age);
		 }
		 public static void main(String agrs[]) {
			 Demo obj=new Demo ("shiva",20);
			 obj.display();
			 
		}
}
