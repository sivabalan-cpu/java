package Day9;
//interface
interface Animal{
	void sound();
	default void run() {
		System.out.println("running");
		
	}static void eat() {
		System.out.println("eating");
	}
}
class dog implements Animal{
	public void sound() {
		System.out.println("bow,bow");
	}
	
}
public class Task2 {

	public static void main(String[] args) {
		dog obj=new dog();
		//obj.run();
		obj.sound();
		
	}

}
