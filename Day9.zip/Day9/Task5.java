package Day9;
//super keyword 
class Animal1{
	String colour="red";
}class Bird{
	String colour="purple";
	
}class Dog extends Bird{
	String colour="white";
	void display() {
		System.out.println(colour);
		System.out.println(super.colour);
	}  
		

	
}

public class Task5 {

	public static void main(String[] args) {
		Dog obj=new Dog();
		obj.display();
		
	}

}
