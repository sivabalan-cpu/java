package Day9;
//super keyword
class Bird4{
	String color="purple";
	void eat() {
		System.out.println("eating...");
	}
}class Dog4 extends Bird4{
	void bark() {
		System.out.println("barking...");
	}
	

void display(){
	super.eat();
	bark();
}}

public class Task6 {

	public static void main(String[] args) {
		Dog4 obj=new Dog4();
		obj.display();

	}

}
