package Day9;
//Abstract class

abstract class Bike1
{
	abstract void run();
}
class Honda extends Bike1
{
	void run() 
	{
		System.out.println("Vehicle");
	}

void play() 
 {
	System.out.println("Playing");
 }
}
public class Bike
{

	public static void main(String[] args)
	{
		
		Bike1 obj = new Honda();
		obj.run();
		Honda obj1 = new Honda();
		obj1.play();
		

	}

}

	


