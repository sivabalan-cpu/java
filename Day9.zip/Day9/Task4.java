package Day9;
//multiple interface
interface print{
	void display();
}
interface copy{
	void show();
}
class Xerox implements print,copy{
	public void display() {
		System.out.println("displaying...");
	}
	public void show() {
		System.out.println("showing...");
	}
}

public class Task4 {

	public static void main(String[] args) {
		Xerox obj=new Xerox();
		obj.display();
		obj.show();

	}

}
