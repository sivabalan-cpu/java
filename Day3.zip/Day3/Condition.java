package Day3;

public class Condition {

	public static void main(String[] args) {
		int a=10;
		if(a == 10) {
			System.out.println("the number is 10");
		}
		if(a<11){
			System.out.println("10 is lessthan 11");
		}
	 if(a>9) {
		System.out.println("is greate");
	}else {
		System.out.println("is lessthan");
	}
	}
}
	
	

