package Day3;
import java.util.Scanner;
public class Task3 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();
		if(a>=0&& a<=100) {
			if(a%2==0) {
		    System.out.println("YES");
			System.out.println(a/2 + " " + a/2);
		}
		else {
			System.out.println("NO");
		}
		}
	   else {
		System.out.println("invalid");
	    }
}
}

