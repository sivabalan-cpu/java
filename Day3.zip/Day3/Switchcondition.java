package Day3;

public class Switchcondition {

	public static void main(String[] args) {
		int num = 1;
		switch(num) {
		case 0:{
			System.out.println("sunday");
		}
		case 1:{
			System.out.println("monday");
			break;
		}
		case 2:{
			System.out.println("tuesday");
		}
		case 3:{
			System.out.println("wednesday");
			}
		case 4:{
			System.out.println("thursday");
		}
		case 5:{
			System.out.println("friday");
			break;
		}
		case 6:{
			System.out.println("saturday");
		}
		default:{
			System.out.println("nothig");
		}
       
	}
       
	}
	
	}
