package Day3;
import java.util.Scanner;
public class Contral2 {

	public static void main(String[] args) {
		Scanner scan =new Scanner(System.in);
		int a =scan.nextInt();
		if(a>=19) {
			System.out.println("eligible to vote");
			if(a>=25) {
				System.out.println("eligible for canditate");
			}
		
		}
		else {
			System.out.println("not ealigible for vote");
		}
		
	}

}
