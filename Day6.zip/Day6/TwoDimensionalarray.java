package Day6;
import java.util.Scanner;
public class TwoDimensionalarray {

	public static void main(String[] args) {
		//int arr[][]= {{1,2,3},{4,5,6},{7,8,9}};
		//for(int i=0;i<arr.length;i++) {
			//for(int j=0;j<arr.length;j++) {
				//System.out.print(arr[i][j] +" ");
								//	}
			//System.out.println();
			//}
		Scanner scan=new Scanner(System.in);
		int row=scan.nextInt();//4
		int col=scan.nextInt();//4
		int arr[][]=new int[row][col];
		for(int i=0;i<row;i++) {//
			for(int j=0;j<col;j++) {//
				arr[i][j]=scan.nextInt();//
			}
		}
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				System.out.print(arr[i][j] +" ");
				}
			System.out.println();
	}
		
	}}
