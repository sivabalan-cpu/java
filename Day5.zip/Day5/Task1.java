package Day5;
import java.util.Scanner;
public class Task1 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		int a=0;
		int b=num;
		while(num>0) {
			int temp=num%10;
			 a=a*10+temp;
			 num=num/10;
			
		}
		if(b==a) {
			System.out.println("it is an polindrome");
		}
		else {
			System.out.println("not a polintrome");
		}
	}
	

}
