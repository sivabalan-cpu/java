package Day5;
import java.util.Scanner;
public class Array {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		int arr[]=new int[num];
		//arr[0]=5;//without user input
		//arr[1]=4;
		//arr[2]=3;
		//arr[3]=2;
		//arr[4]=1;
		for(int i=0;i<arr.length;i++) {
			arr[i]=scan.nextInt();
		}
		for(int i=0;i<arr.length;i++) {
		
			System.out.println(arr[i]);
		}
	
	} 
		
	

}
