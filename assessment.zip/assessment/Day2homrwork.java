package assessment;
import java.util.Scanner;
public class Day2homrwork {

	public static void main(String[] args) {
		        Scanner scan=new Scanner(System.in);
		        int x=scan.nextInt();
		        int y=scan.nextInt();
		        float s=scan.nextFloat();
		        float r=scan.nextFloat();
		        float l=scan.nextFloat();
		        if(s>r && 2*s<r){
		        System.out.println("Invalid Input");
		        }
		        else{
		            float total=(x*s)+(y*r);
		        
		         if(l<=total){
		            System.out.println("Monthly Pass");
		         }
		        else{
		            System.out.println("Solo Trail + Roundabout Ride");
		        }
		        }
		        }
		        
		    
		    


	}


