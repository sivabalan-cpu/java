package Day4;
import java.util.Scanner;
public class Task7 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();//123
		int sum=0;//
		while(a>0) {//123>0
			int temp=a%10;//123%10=3
			sum=sum*10+temp;//3
			a=a/10;//12
			
			
			
		}
		System.out.println(sum);
		
	}

}
