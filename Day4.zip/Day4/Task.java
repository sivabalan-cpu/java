package Day4;
import java.util.Scanner;
public class Task {

	public static void main(String[] args) {
		Scanner scan =new Scanner(System.in);
		int num1=scan.nextInt();
		int num2=scan.nextInt();
		int gcd=1;
		//int min=(num1<num2)? num1:num2;
		//for(int i=min;i>0;i--) {
		for(int i=1;i<=num1 && i<=num2;++i) {
		
			if(num1%i==0 && num2%i==0){
				gcd=i;
				//break;
				
				
			}
			}
		System.out.println(gcd);
		
}}