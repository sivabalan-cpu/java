package Day4;
import java.util.Scanner;

public class Homework {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = scan.nextInt();

        int originalNumber = number;//153
        int result = 0;//0
        int digits = String.valueOf(number).length();//3
        while (number > 0) {//153>0 yes
            int digit = number % 10;//15
            result += Math.pow(digit, digits);
            number /= 10;
        }
        if (result == originalNumber) {
            System.out.println(originalNumber + " is an Armstrong number.");
        } else {
            System.out.println(originalNumber + " is not an Armstrong number.");
        }

       
    }
}

