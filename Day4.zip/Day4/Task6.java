package Day4;
import java.util.Scanner;
public class Task6 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();//912
		int sum=0;//0
		int d=0;//0
		while(a>0){//912>0 yes
			 int temp=a%10;//912%10 =12
			 sum=sum+temp;//0+12=12
			 a=a/10;//912/10=91
		} 
		int temp2=sum%10;//12%10=2
		int temp3=sum/10;//12/10=1
	   d=temp2+temp3;//2+1=3
		System.out.println(d);//3
		
		
			
			 
			 
			 

	}

}