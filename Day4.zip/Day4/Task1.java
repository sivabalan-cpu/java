package Day4;
import java.util.Scanner;
public class Task1 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		 int a=scan.nextInt();
		 int b=scan.nextInt();
		 int addcount=0;
		//for(int i= num;i>=0;i--) {
			//System.out.println(i);
		 for(int i=a;i<=b;i++) {
			if(i%2!=0){//if(i%2==0)even
				addcount++;
				
				
			}
			
		}
		System.out.println(addcount);	
		}

	}


