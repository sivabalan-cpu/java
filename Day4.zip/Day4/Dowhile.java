package Day4;
//import java.util.Scanner;
public class Dowhile {

	public static void main(String[] args) {
		//Scanner scan=new Scanner(System.in);
		int num=10;
		do {
			System.out.println(num);
			num++;
		}
		while(num<=100);

	}

}
