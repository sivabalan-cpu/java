package Day4;
import java.util.Scanner;
class Task5 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		 int a=scan.nextInt();
		 int sum=0;
		 while(a>0){
			 int temp=a%10;
			 sum=sum+temp;
			 a=a/10;
			 System.out.println(sum);
		 }
		 

	}

}
