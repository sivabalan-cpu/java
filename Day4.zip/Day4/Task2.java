package Day4;
import java.util.Scanner;
public class Task2 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		//int fact=1;
		int count=0;
		
		for(int i=1;i<=num;i++) {
			//fact*=i;
			//System.out.println(fact);
			if(num%i==0) {
				count++;
				
				
			}
		}
			System.out.println(count);
		}

}
