package Day4;
import java.io.*;
import java.util.*;

public class Homework3 {

    public static int gcd(int a, int b) {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int gokulPower = sc.nextInt();
        int minorPower = sc.nextInt();
        int totalPower = sc.nextInt();

        int gokulScore = 0;
        int minorScore = 0;
        boolean gokulTurn = true;

        while (totalPower > 0) {
            if (gokulTurn) {
                int g = gcd(gokulPower, totalPower);
                gokulScore += g;
                totalPower -= g;
            } else {
                int g = gcd(minorPower, totalPower);
                minorScore += g;
                totalPower -= g;
            }
            gokulTurn = !gokulTurn;
        }
        if (gokulScore > minorScore) {
            System.out.println("Winner: Gokul");
        } else if (minorScore > gokulScore) {
            System.out.println("Winner: Minor");
        } else {
            System.out.println("It's a draw!");
        }

       
    }
}
