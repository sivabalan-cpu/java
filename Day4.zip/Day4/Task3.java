package Day4;
 import java.util.Scanner;
public class Task3 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int a=scan.nextInt();//7
		int count=0;
		for(int i=2;i<=a;i++) {//i=2/3/4...../7
			if(a%i==0) {//7%2==0 no /7%3==0 no/7%7==0 yes
				count++;//1
				
			}
			
			}
		    if(count==1) {//1==1
		    	System.out.println("prime");//prime
		}
		    else {
		    	System.out.println("not prime");
		    }

	}

}
